Please download and install glpk before running. 

Also, the python package pyomo is required to run the program. 

To run, please follow the following syntax:
	python csp_pyomo.py input.txt output.txt

The input files need to be formatted a certain way(single space to separate words)
for the program to work and so if any problems occur, please contact me. 
